<?php include 'database/dbconnect.php'; ?>
<!DOCTYPE html>
<html>

    <head>
        <title>Welcome to PaCode Assoc</title>
        
        <link rel="stylesheet" type="text/css" href="Css/main.css"/>
        <link rel="stylesheet" type="text/css" href="Css/fontawesome.css">
    	<link rel="stylesheet" type="text/css" href="Css/fontawesome-all.css">
    	<link rel="stylesheet" type="text/css" href="Css/fontawesome.min.css">
    	<link rel="stylesheet" type="text/css" href="Css/fontawesome-all.min.css">
    <style type="text/css">
    body{
        background-color: black;
    }
.mysection{
    background-image: url('project.png');
    background-repeat: no-repeat;
    background-size: cover;
}
    </style>
    </head>
    <div class="mydiv">
    <body>
        <div class="big-wrapper">
<?php include 'header.php';?>
            
            <div class="mysection">
                
            <section class="main-section">
                
<?php include 'loginform.php'; ?>
            
            <aside id="aside-form">

            <?php include 'signupform.php'; ?>

            </aside>

            </section>

            </div>
        
            <footer id="footer">

<?php include 'footer.php';?>
            </footer>
        
        
        </div>
  
    </body>
    </div>
    

</html>