<?php
include 'database/dbconnect.php';
session_start();
$userid = $_SESSION['userid'];
		if(!isset($_SESSION['userid'])){
  		header('Location:index.php');
}

unset($_SESSION['userid']);
session_destroy();
header('Location:index.php');
exit();
?>