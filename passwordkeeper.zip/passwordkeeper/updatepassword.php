<?php include 'database/dbconnect.php';
session_start();
 $userid = $_SESSION['userid'];

if(!isset($_SESSION['userid'])){
  header('Location:index.php');
}

$query = "SELECT * FROM users WHERE username = '$userid' ";
                         $execute = mysqli_query($mysqli,$query);
                         $fetch = mysqli_fetch_array($execute);

 ?>
<!DOCTYPE html>
<html>

    <head>
        <title>Welcome to PaCode Assoc</title>
        
        <link rel="stylesheet" type="text/css" href="Css/main.css"/>
        <link rel="stylesheet" type="text/css" href="Css/fontawesome.css">
    	<link rel="stylesheet" type="text/css" href="Css/fontawesome-all.css">
    	<link rel="stylesheet" type="text/css" href="Css/fontawesome.min.css">
    	<link rel="stylesheet" type="text/css" href="Css/fontawesome-all.min.css">
   <style type="text/css">
    body{
        background-color: black;
    }
.mysection{
    background-image: url('project2.jpg');
    background-repeat: no-repeat;
    background-size: cover;
}
    </style>
    </head>
    <div class="mydiv">
    <body>
        <div class="big-wrapper">
<?php include 'header.php';?>
            
            <div class="mysection">
                
            <section class="main-section">
<div class="usersidebar">
<?php include 'usersidebar.php'; ?>
</div>
            
            <aside id="aside-form" style="margin-top: 80px;">
            <form method="POST" action="" id="updatepass">
                <h2 style="color: ghostwhite;">CHANGE YOUR PASSWORD</h2>
                <p>
                    <label>Username</label>
                    <input type="text" name="username" placeholder="Enter username"/>
                </p>
                <p>
                    <label>Phone Number</label>
                    <input type="text" name="mobile" placeholder="Enter phone number"/>
                </p>
                <p>
                    <label>E-mail address</label>
                    <input type="email" name="email" placeholder="Enter email address"/>
                </p>
                <p>
                    <label>New password</label>
                    <input type="password" name="pass1" placeholder="Enter password"/>
                </p>
                <p>
                    <label>Re-type password</label>
                    <input type="password" name="pass2" placeholder="Re-type password"/>
                </p>
                <p><?php
                     if (isset($_POST['update'])) {
                            $password = md5($_POST['pass1']);
                            $repassword = md5($_POST['pass2']);
                                            // getting data of the user 
                       $getuser = "SELECT * FROM users";
                $execute = mysqli_query($mysqli,$getuser);
                $fetchdata = mysqli_fetch_array($execute);

                $username = $fetchdata['username'];
                $mobilenumber = $fetchdata['mobile'];
                $Email = $fetchdata['email'];

                // if statement to check the valid username for the available user
                if ($_POST['username'] == $username && $_POST['mobile'] == $mobilenumber && $_POST['email'] == $Email) {
                    // create a query to update information to the database
                    $updatequery = "UPDATE users SET password = '$password',confirmpass = '$repassword' ";
                    // passing the query to execute
                    $executeupdate = mysqli_query($mysqli,$updatequery);

                    // display the update message succeed
                    echo "Congraturation! Password Successful Updated";
                }else{
                    echo "Sorry! Incorrect Information .";
                }
            }
?>
                </p>
                  <p>
                    <label>Click to Update</label>
                    <input type="submit" name="update" value="UPDATE" />
                </p>
            </form>

            </aside>

            </section>

            </div>
        
            <footer id="footer" style="margin-top: 10px;">

<?php include 'footer.php';?>
            </footer>
        
        
        </div>
  
    </body>
    </div>
    

</html>