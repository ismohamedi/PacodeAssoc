<!-- codetechdevelopers comminity -->
 <?php include 'database/dbconnect.php'; 
 ?>
 <form method="POST" action="" id="login-form">
                    <h3 style="color: ghostwhite;padding-top: 40px;text-align: left;font-size: 28px;font-weight: 700;">ALREADY A MEMBER! LOGIN NOW</h3>
                    <p>
                    <label>Username</label>
                        <input type="text" name="username" placeholder="Enter Username"/>
                    </p>
                    
                    <p>
                    <label>Password</label>
                        <input type="password" name="password" placeholder="Enter Password"/>
                    </p>
                    <!-- PHP CODES FOR LOGIN BEGINS HERE -->
                    <p style="color: whitesmoke;font-weight: 700;">
                    <?php
                    if (isset($_POST['signin'])) {
                        // get all the necessary login info we need for the authentication
                        $Username = $_POST['username'];
                        $Password = md5($_POST['password']);
                        // check if the user exist in our database for more security
                         $query = "SELECT * FROM users WHERE username = '$Username' AND password = '$Password' ";
                         $execute = mysqli_query($mysqli,$query);
                         $fetch = mysqli_fetch_array($execute);
                         $num = mysqli_num_rows($execute);
                         if ($fetch != 0) {
                            session_start();
                             $_SESSION['userid'] = $fetch['id'];
                           header('Location: home.php');
                         }else{
                            echo "Incorrect Username or Password";
                         }

                         
}

?>
</p>
                    <p>
                        <input type="submit" name="signin" value="SIGN IN"/>
                        <a href="forgotpass.php"  style="color: gold;font-weight: 600;">FORGOT  PASSWORD</a>
                    </p>
                    
                </form>