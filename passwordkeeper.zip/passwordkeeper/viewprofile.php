<?php include 'database/dbconnect.php';
session_start();
 $userid = $_SESSION['userid'];

if(!isset($_SESSION['userid'])){
  header('Location:index.php');
}

$query = "SELECT * FROM users WHERE username = '$userid' ";
                         $execute = mysqli_query($mysqli,$query);
                         $fetch = mysqli_fetch_array($execute);

?>
<!DOCTYPE html>
<html>

    <head>
        <title>Welcome to PaCode Assoc</title>
        
        <link rel="stylesheet" type="text/css" href="Css/main.css"/>
        <link rel="stylesheet" type="text/css" href="Css/fontawesome.css">
    	<link rel="stylesheet" type="text/css" href="Css/fontawesome-all.css">
    	<link rel="stylesheet" type="text/css" href="Css/fontawesome.min.css">
    	<link rel="stylesheet" type="text/css" href="Css/fontawesome-all.min.css">
    <style type="text/css">
    body{
        background-color: black;
    }
.mysection{
    background-image: url('project2.jpg');
    opacity: 0.9;
    background-repeat: no-repeat;
    background-size: cover;
}
    </style>
    </head>
    <div class="mydiv">
    <body>
        <div class="big-wrapper">
<?php include 'header.php';?>
            
            <div class="mysection">
                
            <section class="main-section">
<div class="usersidebar">
<?php include 'usersidebar.php'; ?>
</div>
            
            <aside id="aside-form" style="margin-top: -180px;">

            <?php include 'profileedit.php'; ?>

            </aside>

            </section>

            </div>
        
            <footer id="footer" style="margin-top: 10px;">

<?php include 'footer.php';?>
            </footer>
        
        
        </div>
  
    </body>
    </div>
    

</html>