<?php include 'database/dbconnect.php';
session_start();
 $userid = $_SESSION['userid'];

if(!isset($_SESSION['userid'])){
  header('Location:index.php');
}
 ?>
<!DOCTYPE html>
<html>

    <head>
        <title>Welcome to PaCode Assoc</title>
        
        <link rel="stylesheet" type="text/css" href="Css/main.css"/>
        <link rel="stylesheet" type="text/css" href="Css/fontawesome.css">
    	<link rel="stylesheet" type="text/css" href="Css/fontawesome-all.css">
    	<link rel="stylesheet" type="text/css" href="Css/fontawesome.min.css">
    	<link rel="stylesheet" type="text/css" href="Css/fontawesome-all.min.css">
               <link rel="stylesheet" type="text/css" href="font-css/fontawesome.min.css">
               <link rel="stylesheet" type="text/css" href="font-css/fontawesome.css">
               <link rel="stylesheet" type="text/css" href="font-css/fontawesome-all.min.css">
               <link rel="stylesheet" type="text/css" href="font-css/fontawesome-all.css">
               <link rel="stylesheet" type="text/css" href="font-css/fa-brands.min.css">
               <link rel="stylesheet" type="text/css" href="font-css/fa-brands.css">
               <link rel="stylesheet" type="text/css" href="font-css/fa-regular.css">
    <style type="text/css">
    body{
        background-color: black;
    }
th{
    background: -webkit-linear-gradient(90deg,black,white);
    opacity: 0.8;
    border-radius: 5px;
}
tr{
    background: ghostwhite;
}
table{
    width: 800px;
    font-size: 20px;
    border-radius: 5px;
}
td{
    border: 2px solid #ccc;
    border-radius: 5px;
}
<style type="text/css">
    body{
        background-color: black;
    }
.mysection{
    background-image: url('project2.jpg');
    background-repeat: no-repeat;
    background-size: cover;
}
    </style>

    </style>
    </head>
    <div class="mydiv">
    <body>
        <div class="big-wrapper">
<?php include 'header.php';?>
            
            <div class="mysection">
            <section class="main-section">
<div class="usersidebar">
<?php include 'usersidebar.php'; ?>
</div>

<div class="Accounts">
<section class="accounts">
         <p style="margin-top: -350px;">
         <h2 style="text-align: center;
    color: whitesmoke;">ACCOUNTS INFORMATION SAVED CURRENTLY</h2>
            <table style="border: 2px solid darkgreen;text-align: center;margin-left: 390px;">
            <!-- PHP CODE FOR RETRIEVING ALL OF THE DATA FROM THE ACCOUNT -->
        
                <tr>
                    <th>ACCOUNT TYPE</th>
                    <th>USERNAME</th>
                    <th>PASSWORD</th>
                </tr>
                    <?php
            $getquery = "SELECT * FROM accounts WHERE accid = $userid";
           $result = mysqli_query($mysqli,$getquery)or die(mysqli_error($mysqli));

                                while($row = mysqli_fetch_object($result)){
            ?>
                <tr >
                    <td><?php echo $row->acctype;?></td>
                    <td><?php echo $row->username;?></td>
                    <td><?php echo $row->password;?></td>
                </tr>
                <?php }?>
            </table>
        </p>
        
</section>
</div>
            
            <aside id="aside-form" style="margin-top: auto;">

            <?php include 'feedback.php'; ?>

            </aside>

            </section>

            </div>
        
            <footer id="footer" style="margin-top: 10px;">

<?php include 'footer.php';?>
            </footer>
        
        
        </div>
  
    </body>
    </div>
    

</html>