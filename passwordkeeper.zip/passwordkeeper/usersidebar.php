<aside style="">
   <i class="fas fa-user" style="color: goldenrod;font-size: 40px;padding: 5px;" ></i> <span style="color: whitesmoke;font-size: 18px;text-transform: uppercase; font-weight: 700;font-family: Tahoma;"> <?php
 $userquery = "SELECT * FROM users WHERE id = '$userid'";
 $execute = mysqli_query($mysqli,$userquery);
 $getarray = mysqli_fetch_array($execute);

     echo $getarray['username']; ?></span>
    <ul>
        <li><a href="viewprofile.php">View Profile</a></li>
        <li><a href="viewstore.php">View Store</a></li>
        <li><a href="editstore.php">Edit Store</a></li>
        <li><a href="updatepassword.php">Change Password</a></li>
        <li><a href="signout.php">Sign Out</a></li>
    </ul>
</aside>