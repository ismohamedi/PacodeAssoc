<?php include 'database/dbconnect.php';
     $query = "SELECT * FROM users  WHERE id = '$userid' ";
                         $execute = mysqli_query($mysqli,$query);
                         $fetch = mysqli_fetch_array($execute);
 ?>
<form method="POST" action="" id="register-form">
                <h3 style="color: ghostwhite;font-size: 28px;font-weight: 700;">CURRENT INFORMATION </h3>
                    <p>
                    <label>First Name</label>
                        <input type="text" name="fname" value="<?php echo $fetch['fname'];?>" readonly=""/>
                    </p>
                    <p>
                    <label>Last Name</label>
                        <input type="text" name="lname" value="<?php echo $fetch['lname'];?>" readonly="" />
                    </p>
                    <p>
                    <label>User Name</label>
                        <input type="text" name="username" value="<?php echo $fetch['username'];?>" required="" />
                    </p>
                    <p>
                    <label>E-mail</label>
                        <input type="email" name="email" value="<?php echo $fetch['email'];?>" required="" />
                    </p>
                      <p>
                    <label>Mobile Number</label>
                        <input type="text" name="mobile" value="<?php echo $fetch['mobile'];?>" required="" />
                    </p>
                    <p style="color: darkgreen;font-weight: 700;">
                        <!-- PHP UPDATE CODE BEGINS HERE -->
                        <?php
                        if (isset($_POST['update'])) {
                            $newusername = $_POST['username'];
                            $newmobile = $_POST['mobile'];
                            $newemail = $_POST['email'];
                
                       $getuser = "SELECT * FROM users";
                $execute = mysqli_query($mysqli,$getuser);
                $fetchdata = mysqli_fetch_array($execute);

                $username = $fetchdata['username'];
                $mobilenumber = $fetchdata['mobile'];

                // if statement to check the valid username for the available user
                if ($_POST['username'] == $username && $_POST['mobile'] == $mobilenumber) {
                    // create a query to update information to the database
                    $updatequery = "UPDATE users SET username = '$newusername',mobile = '$newmobile',email = '$newemail' ";
                    // passing the query to execute
                    $executeupdate = mysqli_query($mysqli,$updatequery);

                    // display the update message succeed
                    echo "Congraturation! Details Successful Updated";
                }else{
                    echo "Sorry! Incorrect Information .";
                }
            }

 ?>
                    </p>
                   
                    
                    <p>
                    <label>Edit/Save Now</label>
                        <input type="submit" name="update" value="SAVE"/>
                    </p>
                    
                </form>