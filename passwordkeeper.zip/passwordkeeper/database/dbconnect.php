<?php
$host = 'localhost';
$username = 'root';
$password = '';
$dbname = 'PacodeAssoc';
// establish connection of the database created
$mysqli = mysqli_connect($host,$username,$password,$dbname);
// creating an if statement for the verification of the connection
if (!$mysqli) {
	echo "Sorry connection failed" or die(mysql_error());
}

?>