<?php
include 'database/dbconnect.php';
session_start();
$userid = $_SESSION['username'];
		if(!isset($_SESSION['username'])){
  		header('Location:index.php');
}
 
if(isset($_POST['send'])) {
  //get the variable in the field
  $feedback = $_POST['feedback'];
 
  //creating a query to inser a question in to database
  $query = "INSERT INTO feedbacks (username,feedback,sent_date) VALUES('$userid','$feedback',now())";

  $result = mysqli_query($mysqli,$query);
  header('Location:home.php');
}else{
  echo "Only for FeedBack report !! ";
}

?>