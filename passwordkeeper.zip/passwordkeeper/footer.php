    <span>E-mail <i class="fas fa-envelope"></i> :codetechdevelopers1@gmail.com</span><br/> 
                <span>Developed by <i class="fas fa-heart" style="color: red;"></i> CodeTechDevelopers</span><br/>
            <span style="font-style: italic;font-family: times;">Copyright &copy All right reserved 2019</span>