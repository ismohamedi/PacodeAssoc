<?php include 'database/dbconnect.php';
session_start();
 $userid = $_SESSION['userid'];
if(!isset($_SESSION['userid'])){
  header('Location:index.php');
}
?>
<!DOCTYPE html>
<html>

    <head>
        <title>Welcome to PaCode Assoc</title>
        
        <link rel="stylesheet" type="text/css" href="Css/main.css"/>
        <link rel="stylesheet" type="text/css" href="Css/fontawesome.css">
    	<link rel="stylesheet" type="text/css" href="Css/fontawesome-all.css">
    	<link rel="stylesheet" type="text/css" href="Css/fontawesome.min.css">
    	<link rel="stylesheet" type="text/css" href="Css/fontawesome-all.min.css">
               <link rel="stylesheet" type="text/css" href="font-css/fontawesome.min.css">
               <link rel="stylesheet" type="text/css" href="font-css/fontawesome.css">
               <link rel="stylesheet" type="text/css" href="font-css/fontawesome-all.min.css">
               <link rel="stylesheet" type="text/css" href="font-css/fontawesome-all.css">
               <link rel="stylesheet" type="text/css" href="font-css/fa-brands.min.css">
               <link rel="stylesheet" type="text/css" href="font-css/fa-brands.css">
               <link rel="stylesheet" type="text/css" href="font-css/fa-regular.css">
    
    </head>
    <div class="mydiv" style="background: url('project2.jpg');">
    <body>
        <div class="big-wrapper">
        <div class="position">
<?php include 'header.php';?>
            </div>
            <div class="mysection">
            <section class="main-section">
<div class="usersidebar">
<?php include 'usersidebar.php'; ?>
</div>

<div class="Accounts">
<section class="accounts">
    <form method="POST" action="" style="text-align: center;margin-top: -350px;" id="accountform">
         <p>
         <img src="images/circle-linkedin-icon-8333.svg" style="width: 100px; height: 100px;" />
         <img src="images/circle-instagram-icon-8325.svg" style="width: 100px; height: 100px;" />
         <img src="images/circle-facebook-icon-8301.svg" style="width: 100px; height: 100px;" />
         </p>
         <p>
            <label>Username</label>
            <input type="text" name="username" placeholder="Enter username"/>
            </p>
            <p>
            <label>Password</label>
            <input type="password" name="password" placeholder="Enter password"></input>
        </p>
         <p>
            <select name="acctype">Choose Account
            <option>Facebook</option>
            <option>Twitter</option>
            <option>Instagram</option>
            <option>LinkedIn</option>
            <option>Gmail</option>
            <option>Yahoo</option>
            </select>
          
        </p>
        <p style="color: darkgreen;font-weight: 700;font-size: 18px;">
            <!-- PHP CODE FOR SAVING THE PASSWORDS ACCOUNTS BEGINS HERE -->
            <?php
            if (isset($_POST['save'])) {
                $Accusername = $_POST['username'];
                $Accpassword = $_POST['password'];
                $Acctype = $_POST['acctype'];
                // creating a query to insert data
                $insertacc = "INSERT INTO accounts(accid,acctype,username,password)VALUES('$userid','$Acctype','$Accusername','$Accpassword')";
                $accexecute = mysqli_query($mysqli,$insertacc)or die(mysqli_error($mysqli));
                // check the insert query
                if ($accexecute) {
                    echo "Account Info has been saved successful";
                }else{
                    echo "Oops! An Error Occured during the process .";
                }
            }
            ?>
        </p>
        <p>
            <input type="submit" name="save" value="SAVE"></input>
        </p>
    </form>
</section>
</div>
            
            <aside id="aside-form" style="margin-top: -150px;">

            <?php include 'feedback.php'; ?>

            </aside>

            </section>

            </div>
        
            <footer id="footer" style="margin-top: 10px;">

<?php include 'footer.php';?>
            </footer>
        
        
        </div>
  
    </body>
    </div>
    

</html>