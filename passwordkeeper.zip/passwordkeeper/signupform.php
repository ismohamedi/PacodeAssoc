<?php include 'database/dbconnect.php'; ?>
<form method="POST" action="" id="register-form">
                <h3 style="color: ghostwhite;font-size: 28px;font-weight: 700;">REGISTER NOW FOR FREE</h3>
                    <p>
                    <label>First Name</label>
                        <input type="text" name="fname" placeholder="Enter first name" required="" />
                    </p>
                    <p>
                    <label>Last Name</label>
                        <input type="text" name="lname" placeholder="Enter last name" required="" />
                    </p>
                    <p>
                    <label>User Name</label>
                        <input type="text" name="username" placeholder="Enter Username" required="" />
                    </p>
                    <p>
                    <label>E-mail</label>
                        <input type="email" name="email" placeholder="Enter E-mail" required="" />
                    </p>
                    <p>
                    <label>Mobile Number</label>
                        <input type="text" name="mobile" placeholder="Enter phone number" required="" />
                    </p>
                    
                    <p>
                    <label>Password</label>
                        <input type="password" name="password" placeholder="Enter Password" required="" />
                    </p>
                    <p>
                    <label>Confirm password</label>
                        <input type="password" name="confirmpassword" placeholder="Re-type password" required="" />
                    </p>
                    <p >
                        <?php
                        if (isset($_POST['signup'])) {
                            // get all the necessary variable to be saved to the database
                            $firstname = $_POST['fname'];
                            $lastname = $_POST['lname'];
                            $username = $_POST['username'];
                            $email = $_POST['email'];
                             $phonenumber = $_POST['mobile'];
                            $password = md5($_POST['password']);
                            $conpassword = md5($_POST['confirmpassword']);
                            // creating a query to get all the data available in the database store inorder ot get the list of users we have
                            $userquery = "SELECT * FROM users";
                            $execute = mysqli_query($mysqli,$userquery);
                            $getusers = mysqli_fetch_assoc($execute);

                            // comparing the password entered by the user including the username existence in the list of user to the database
                            if ($username == $getusers['username']) {
                                echo "Sorry Username Already Exist";
                            }elseif ($password == $conpassword) {
                                // creating a query to insert the new user into the database
                                $insertquery = "INSERT INTO users(fname,lname,email,username,mobile,password,confirmpass)VALUES('$firstname','$lastname'
                               ,'$email','$username','$phonenumber','$password','$conpassword')";
                                $executeinsert = mysqli_query($mysqli,$insertquery);
                                // creating an if statement to check the execution of the query
                                if ($executeinsert) {
                                    echo  '<p style="color: darkgreen;font-weight: 700;">Registration Successful !! Welcome to the Pacode Assoc .</p>';
                                }else{
                                    echo '<p style="color: red;font-weight: 700;">Sorry try again, some Errors Occurred .</p>';
                                }
                            }else{
                                echo '<p style="color: red;font-weight: 700;">Sorry password did not match !! Try again .</p>';
                            }
                        }

?>
                    </p>
                    
                    <p>
                    <label>Sign Up Now</label>
                        <input type="submit" name="signup" value="SIGN UP"/>
                    </p>
                    
                </form>