<form method="POST" action="" style="float: left;margin-top: 200px;" id="textarea">
	<h2 style="color: ghostwhite;">SEND FEEDBACK</h2>
	<textarea name="feedback" placeholder="Write feedback" style=" border-radius: 5px;padding: 5px;border: 2px solid green;font-size: 20px;font-family: 'titillium web';width: 400px;height: 150px;margin-bottom: 40px;margin-right: -100px;-webkit-box-shadow: rgb(110,110,210) 5px 10px 5px;"></textarea>
	<!-- PHP CODE BEGINS HERE -->
	<input type="submit" name="send" value="SEND" style="float: right;margin-top: 170px;margin-left: 0px;" />
	<p style="color: darkgreen;font-size: 20px;font-weight: 600;">
<?php
$userid = $_SESSION['userid'];
		if(!isset($_SESSION['userid'])){
  		header('Location:index.php');
}
 
if(isset($_POST['send'])) {
  //get the variable in the field
  $postfeed = $_POST['feedback'];
  // creating a query to get username specific
  $userquery = "SELECT * FROM users WHERE id = '$userid'";
 $execute = mysqli_query($mysqli,$userquery);
 $getarray = mysqli_fetch_array($execute);

     $Username = $getarray['username'];
 
  //creating a query to inser a question in to database
  $query = "INSERT INTO questions (ref_id,username,questiontext,postdate) VALUES('$userid','$Username','$postfeed',now())";

  $result = mysqli_query($mysqli,$query)or die(mysqli_error($mysqli));
  echo "Thank , Your feed back has been sent .";
}else{
  
}

?>
</p>
</form>