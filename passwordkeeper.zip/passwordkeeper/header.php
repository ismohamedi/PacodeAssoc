 <!-- by codetechdevelopers community -->
  <header id="header">
                <img src="logo/dino2.jpg" style="width: 250px; height: 150px; "><h1 style="font-family: times;font-size: 2.5em;margin-top: -90px;position: relative;margin-left: 250px; border: 5px solid red; width: 500px;text-align: center;"> PACODE | ASSOC</h1>
                <h4 style="color: darkgreen;font-style: italic;font-weight: 600;font-family: tah;">Store as many passwords as you can for free with <b>"PaCode"</b> and Access with only One Account .</h4>
                <span style="font-weight: 600;">A WORLD OF JUST A SINGLE CLICK ACCESS .</span>
                 </header>
            
            
            <nav id="topnav">
            <ul>
                <li><a href="home.php"><i class="fas fa-home" style="color: gold;opacity: 0.7;"></i> home</a></li>
                <li><a href="#"><i class="fas fa-about"></i>About us</a></li>
                <li><a href="#"><i class="fas fa-phone" style="color: gold;opacity: 0.7;"></i> Contact us</a></li>
            </ul>
            </nav>

          